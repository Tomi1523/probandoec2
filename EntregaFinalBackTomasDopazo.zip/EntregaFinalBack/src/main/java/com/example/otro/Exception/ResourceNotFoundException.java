package com.example.otro.Exception;



public class ResourceNotFoundException extends Exception {

    public ResourceNotFoundException() {
        super("no se encontro el recurso");
    }


}
