package com.example.otro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtroApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtroApplication.class, args);
	}

}
